<?php

/**
 * Hello friends!
 */

function  evgeniy_get_content(){
    echo "Evgeniy";
}