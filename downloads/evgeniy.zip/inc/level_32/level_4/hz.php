<?php

echo "hz.php";


echo "тут должно изменить Evgeniy asd";