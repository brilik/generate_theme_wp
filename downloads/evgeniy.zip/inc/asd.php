test file asd.php


Theme Name: Evgeniy
Theme URI: https://github.com/brilik
Author: Vitalii Bryl
Author URI: https://iBryl.store/profile/
Description: This is theme best of the best!
Text Domain: evgeniy